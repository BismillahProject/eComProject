﻿var rs = { IsSuccess:false, MessageText:"", Status:-1 };

function IsSuccess() {
    return rs.IsSuccess;
}

function MessageText() {
    return rs.MessageText;
}

function Status() {
    return rs.Status;
}

