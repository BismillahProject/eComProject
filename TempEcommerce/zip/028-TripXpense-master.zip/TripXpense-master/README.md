TripXpense
==========

Simple Trip Expense app created using Xamarin

So far:

1. Add/Edit/Delete Trips
2. Add/Edit/Delete Expenses
