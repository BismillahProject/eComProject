Zest Theme For LemonStand Cloud
=================

A simple, minimal and responsive theme for LemonStand thats easy to customize.

It's based on the Foundation CSS framework (version 3).

# Features

* Responsive / mobile-friendly
* Customizable colors for buttons, links, sale prices and more
* Upload your own logo and banner image
* Upload your own favicon.ico image
* Simple checkout pages
* Breadcrumbs
* Supports product options, variants, attributes
* Guest and registered checkout
* "Copy billing information" on checkout